import java.util.*;

public class week6 {

    static Scanner scanner = new Scanner(System.in);
    static Random random = new Random();

    static String[] easyWords = {
            "APPLE", "BALL", "CAT", "DOG", "FISH"
    };

    static String[] mediumWords = {
            "COMPUTER", "KEYBOARD", "MONITOR", "PROGRAM", "NETWORK"
    };

    static String[] hardWords = {
            "ALGORITHM", "DATABASE", "INTERFACE", "PROGRAMMING", "DEVELOPMENT"
    };

    public static String scrambleWord(String word) {
        List<Character> letters = new ArrayList<>();

        for (char c : word.toCharArray()) {
            letters.add(c);
        }

        Collections.shuffle(letters);

        StringBuilder scrambled = new StringBuilder();

        for (char c : letters) {
            scrambled.append(c);
        }

        return scrambled.toString();
    }

    public static void playGame(String[] words, int hintLimit) {
        String word = words[random.nextInt(words.length)];
        String scrambledWord = scrambleWord(word);

        int hintsLeft = hintLimit;

        System.out.println("\nScrambled Word: " + scrambledWord);
        System.out.println("Type your answer or type HINT");

        while (true) {
            System.out.print("\nYour Answer: ");
            String answer = scanner.nextLine().toUpperCase();

            if (answer.equals("HINT")) {
                if (hintsLeft > 0) {
                    System.out.println("Hint: The first letter is " + word.charAt(0));
                    hintsLeft--;
                    System.out.println("Hints remaining: " + hintsLeft);
                } else {
                    System.out.println("No hints remaining!");
                }
            } else if (answer.equals(word)) {
                System.out.println("Correct! You guessed the word.");
                break;
            } else {
                System.out.println("Wrong answer! Try again.");
            }
        }
    }

    public static void main(String[] args) {

        System.out.println("================================");
        System.out.println("     WORD SCRAMBLE GAME");
        System.out.println("================================");

        System.out.println("\nChoose Difficulty Level:");
        System.out.println("1. Easy");
        System.out.println("2. Medium");
        System.out.println("3. Hard");

        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine();

        switch (choice) {
            case 1:
                System.out.println("\nYou selected EASY level.");
                playGame(easyWords, 3);
                break;

            case 2:
                System.out.println("\nYou selected MEDIUM level.");
                playGame(mediumWords, 2);
                break;

            case 3:
                System.out.println("\nYou selected HARD level.");
                playGame(hardWords, 1);
                break;

            default:
                System.out.println("Invalid choice!");
        }

        System.out.println("\nThank you for playing!");
    }
}