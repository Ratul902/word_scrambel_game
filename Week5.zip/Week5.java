
import java.util.*;

public class Week5 {

    static String[] wordBank = {
            "APPLE",
            "BANANA",
            "ORANGE",
            "COMPUTER",
            "KEYBOARD",
            "PROGRAMMING",
            "JAVA",
            "SCHOOL",
            "STUDENT",
            "UNIVERSITY"
    };

    static ArrayList<String> usedWords = new ArrayList<>();
    static Random random = new Random();
    static Scanner scanner = new Scanner(System.in);
    static int score = 0;

    public static void main(String[] args) {

        int round = 1;

        System.out.println("=================================");
        System.out.println("       WORD SCRAMBLE GAME");
        System.out.println("=================================");

        while (true) {

            System.out.println("\n---------- ROUND " + round + " ----------");

            if (usedWords.size() == wordBank.length) {
                System.out.println("All words have been used!");
                break;
            }

            String originalWord = getUniqueRandomWord();
            String scrambledWord = scrambleWord(originalWord);

            System.out.println("Scrambled Word: " + scrambledWord);

            System.out.print("Enter your answer: ");
            String answer = scanner.nextLine().trim();

            if (answer.equalsIgnoreCase(originalWord)) {
                System.out.println("Correct!");
                score++;
            } else {
                System.out.println("Wrong!");
                System.out.println("Correct answer: " + originalWord);
            }

            System.out.println("Current Score: " + score);

            System.out.print("\nDo you want to continue? (Y/N): ");
            String choice = scanner.nextLine().trim();

            if (choice.equalsIgnoreCase("Y") || choice.equalsIgnoreCase("YES")) {
                round++;
            } else {
                break;
            }
        }

        System.out.println("\n=================================");
        System.out.println("           GAME OVER");
        System.out.println("=================================");
        System.out.println("Total Rounds Played: " + round);
        System.out.println("Final Score: " + score);
        System.out.println("Thank you for playing!");

        scanner.close();
    }

    public static String getUniqueRandomWord() {

        String word;

        do {
            int index = random.nextInt(wordBank.length);
            word = wordBank[index];
        } while (usedWords.contains(word));

        usedWords.add(word);

        return word;
    }

    public static String scrambleWord(String word) {

        ArrayList<Character> characters = new ArrayList<>();

        for (char c : word.toCharArray()) {
            characters.add(c);
        }

        String scrambled;

        do {
            Collections.shuffle(characters);

            StringBuilder result = new StringBuilder();

            for (char c : characters) {
                result.append(c);
            }

            scrambled = result.toString();

        } while (scrambled.equals(word));

        return scrambled;
    }
}