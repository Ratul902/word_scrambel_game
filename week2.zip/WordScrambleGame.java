
import java.util.Random;

public class WordScrambleGame {

    public static String scrambleWord(String word) {

        char[] letters = word.toCharArray();
        Random random = new Random();

        for (int i = 0; i < letters.length; i++) {

            int j = random.nextInt(letters.length);

            char temp = letters[i];
            letters[i] = letters[j];
            letters[j] = temp;
        }

        return new String(letters);
    }

    public static void main(String[] args) {

        System.out.println("=================================");
        System.out.println("     WORD SCRAMBLE GAME");
        System.out.println("=================================");

        String[] words = {
                "APPLE",
                "BANANA",
                "JAVA",
                "PROGRAM",
                "KEYBOARD",
                "MOUSE",
                "MONITOR",
                "SCREEN",
                "COMPUTER",
                "LANGUAGE"
        };

        Random random = new Random();

        String originalWord = words[random.nextInt(words.length)];

        String scrambledWord = scrambleWord(originalWord);

        System.out.println("Word Bank Loaded Successfully!");
        System.out.println("Scrambled Word: " + scrambledWord);
    }
}