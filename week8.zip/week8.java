import javax.swing.*;
import java.awt.*;
import java.util.Random;

public class week8 extends JFrame {

    String[] words = {
            "APPLE",
            "BANANA",
            "ORANGE",
            "MANGO",
            "COMPUTER",
            "PROGRAM",
            "KEYBOARD",
            "ELEPHANT"
    };

    String currentWord;
    String scrambledWord;

    int score = 0;
    int highScore = 0;
    int timeLeft = 60;
    int questionNumber = 0;
    int correctAnswers = 0;
    int totalQuestions = 10;

    JLabel wordLabel;
    JLabel scoreLabel;
    JLabel timerLabel;
    JLabel questionLabel;

    JTextField answerField;

    JButton submitButton;
    JButton nextButton;
    JButton instructionButton;

    Timer timer;
    Random random = new Random();

    public week8() {

        showWelcomeScreen();
    }

    void showWelcomeScreen() {

        setTitle("Word Scramble Game");
        setSize(550, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        JLabel titleLabel = new JLabel("WORD SCRAMBLE GAME");
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 30));

        JLabel welcomeLabel = new JLabel("Welcome to the Game!");
        welcomeLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        welcomeLabel.setFont(new Font("Arial", Font.PLAIN, 20));

        JButton startButton = new JButton("Start Game");
        startButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        startButton.setPreferredSize(new Dimension(150, 40));

        instructionButton = new JButton("Instructions");
        instructionButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton exitButton = new JButton("Exit");
        exitButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        panel.add(Box.createVerticalStrut(60));
        panel.add(titleLabel);

        panel.add(Box.createVerticalStrut(20));
        panel.add(welcomeLabel);

        panel.add(Box.createVerticalStrut(40));
        panel.add(startButton);

        panel.add(Box.createVerticalStrut(15));
        panel.add(instructionButton);

        panel.add(Box.createVerticalStrut(15));
        panel.add(exitButton);

        add(panel);

        startButton.addActionListener(e -> startGame());

        instructionButton.addActionListener(e -> showInstructions());

        exitButton.addActionListener(e -> System.exit(0));

        setVisible(true);
    }

    void showInstructions() {

        JOptionPane.showMessageDialog(
                this,
                "WORD SCRAMBLE GAME INSTRUCTIONS\n\n" +
                        "1. A scrambled word will be displayed.\n" +
                        "2. Type the correct original word.\n" +
                        "3. Click Submit Answer.\n" +
                        "4. Each correct answer gives 10 points.\n" +
                        "5. You have 60 seconds to play.\n" +
                        "6. Try to achieve the highest score.",
                "Game Instructions",
                JOptionPane.INFORMATION_MESSAGE
        );
    }

    void startGame() {

        getContentPane().removeAll();

        score = 0;
        timeLeft = 60;
        questionNumber = 0;
        correctAnswers = 0;

        setLayout(new BorderLayout());

        JPanel topPanel = new JPanel(new GridLayout(1, 3));

        scoreLabel = new JLabel("Score: 0", SwingConstants.CENTER);
        timerLabel = new JLabel("Time: 60", SwingConstants.CENTER);
        questionLabel = new JLabel("Question: 0/" + totalQuestions, SwingConstants.CENTER);

        scoreLabel.setFont(new Font("Arial", Font.BOLD, 16));
        timerLabel.setFont(new Font("Arial", Font.BOLD, 16));
        questionLabel.setFont(new Font("Arial", Font.BOLD, 16));

        topPanel.add(scoreLabel);
        topPanel.add(timerLabel);
        topPanel.add(questionLabel);

        add(topPanel, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));

        JLabel titleLabel = new JLabel("Unscramble the Word");
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 25));

        wordLabel = new JLabel("");
        wordLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        wordLabel.setFont(new Font("Arial", Font.BOLD, 32));

        answerField = new JTextField();
        answerField.setMaximumSize(new Dimension(280, 40));
        answerField.setAlignmentX(Component.CENTER_ALIGNMENT);

        submitButton = new JButton("Submit Answer");
        submitButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        nextButton = new JButton("Next Word");
        nextButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton instructionButton2 = new JButton("Instructions");
        instructionButton2.setAlignmentX(Component.CENTER_ALIGNMENT);

        centerPanel.add(Box.createVerticalStrut(30));
        centerPanel.add(titleLabel);

        centerPanel.add(Box.createVerticalStrut(30));
        centerPanel.add(wordLabel);

        centerPanel.add(Box.createVerticalStrut(25));
        centerPanel.add(answerField);

        centerPanel.add(Box.createVerticalStrut(15));
        centerPanel.add(submitButton);

        centerPanel.add(Box.createVerticalStrut(10));
        centerPanel.add(nextButton);

        centerPanel.add(Box.createVerticalStrut(10));
        centerPanel.add(instructionButton2);

        add(centerPanel, BorderLayout.CENTER);

        submitButton.addActionListener(e -> checkAnswer());

        nextButton.addActionListener(e -> nextWord());

        instructionButton2.addActionListener(e -> showInstructions());

        nextWord();

        timer = new Timer(1000, e -> {

            timeLeft--;

            timerLabel.setText("Time: " + timeLeft);

            if (timeLeft <= 0) {
                endGame();
            }
        });

        timer.start();

        revalidate();
        repaint();
    }

    void nextWord() {

        if (questionNumber >= totalQuestions) {
            endGame();
            return;
        }

        questionNumber++;

        questionLabel.setText(
                "Question: " + questionNumber + "/" + totalQuestions
        );

        currentWord = words[random.nextInt(words.length)];

        scrambledWord = scrambleWord(currentWord);

        wordLabel.setText(scrambledWord);

        answerField.setText("");

        answerField.requestFocus();
    }

    String scrambleWord(String word) {

        char[] letters = word.toCharArray();

        for (int i = 0; i < letters.length; i++) {

            int j = random.nextInt(letters.length);

            char temp = letters[i];

            letters[i] = letters[j];

            letters[j] = temp;
        }

        return new String(letters);
    }

    void checkAnswer() {

        String answer = answerField.getText().trim().toUpperCase();

        if (answer.isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please enter an answer."
            );

            return;
        }

        if (answer.equals(currentWord)) {

            score += 10;
            correctAnswers++;

            scoreLabel.setText("Score: " + score);

            if (score > highScore) {
                highScore = score;
            }

            JOptionPane.showMessageDialog(
                    this,
                    "Correct Answer!\n+10 Points"
            );

            nextWord();

        } else {

            JOptionPane.showMessageDialog(
                    this,
                    "Wrong Answer!\nTry Again."
            );
        }
    }

    void endGame() {

        if (timer != null) {
            timer.stop();
        }

        answerField.setEnabled(false);
        submitButton.setEnabled(false);
        nextButton.setEnabled(false);

        if (score > highScore) {
            highScore = score;
        }

        String message =
                "GAME SUMMARY\n\n" +
                        "Total Questions: " + totalQuestions + "\n" +
                        "Correct Answers: " + correctAnswers + "\n" +
                        "Wrong Answers: " + (questionNumber - correctAnswers) + "\n" +
                        "Final Score: " + score + "\n" +
                        "High Score: " + highScore;

        int option = JOptionPane.showOptionDialog(
                this,
                message,
                "Game Over",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                null,
                new String[]{"Play Again", "Exit"},
                "Play Again"
        );

        if (option == 0) {
            startGame();
        } else {
            System.exit(0);
        }
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            new week8();
        });
    }
}