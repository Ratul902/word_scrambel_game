import javax.swing.*;
import java.awt.*;
import java.util.Random;

public class week7 extends JFrame {

    String[] words = {
            "APPLE",
            "BANANA",
            "ORANGE",
            "MANGO",
            "COMPUTER",
            "PROGRAM",
            "KEYBOARD",
            "ELEPHANT"
    };

    String currentWord;
    String scrambledWord;

    int score = 0;
    int highScore = 0;
    int timeLeft = 30;

    JLabel wordLabel;
    JLabel scoreLabel;
    JLabel timerLabel;

    JTextField answerField;

    JButton submitButton;
    JButton nextButton;

    Timer timer;
    Random random = new Random();

    public week7() {

        setTitle("Word Scramble Game");
        setSize(500, 350);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel topPanel = new JPanel(new GridLayout(1, 2));

        scoreLabel = new JLabel("Score: 0", SwingConstants.CENTER);
        timerLabel = new JLabel("Time: 30", SwingConstants.CENTER);

        topPanel.add(scoreLabel);
        topPanel.add(timerLabel);

        add(topPanel, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));

        JLabel titleLabel = new JLabel("Unscramble the Word");
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 22));

        wordLabel = new JLabel("");
        wordLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        wordLabel.setFont(new Font("Arial", Font.BOLD, 28));

        answerField = new JTextField();
        answerField.setMaximumSize(new Dimension(250, 35));
        answerField.setAlignmentX(Component.CENTER_ALIGNMENT);

        submitButton = new JButton("Submit Answer");
        submitButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        nextButton = new JButton("Next Word");
        nextButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        centerPanel.add(Box.createVerticalStrut(30));
        centerPanel.add(titleLabel);

        centerPanel.add(Box.createVerticalStrut(25));
        centerPanel.add(wordLabel);

        centerPanel.add(Box.createVerticalStrut(25));
        centerPanel.add(answerField);

        centerPanel.add(Box.createVerticalStrut(15));
        centerPanel.add(submitButton);

        centerPanel.add(Box.createVerticalStrut(10));
        centerPanel.add(nextButton);

        add(centerPanel, BorderLayout.CENTER);

        submitButton.addActionListener(e -> checkAnswer());

        nextButton.addActionListener(e -> nextWord());

        startGame();
    }

    void startGame() {

        score = 0;
        timeLeft = 60;

        scoreLabel.setText("Score: " + score);
        timerLabel.setText("Time: " + timeLeft);

        answerField.setEnabled(true);
        submitButton.setEnabled(true);
        nextButton.setEnabled(true);

        nextWord();

        timer = new Timer(1000, e -> {

            timeLeft--;

            timerLabel.setText("Time: " + timeLeft);

            if (timeLeft <= 0) {
                endGame();
            }
        });

        timer.start();
    }

    void nextWord() {

        currentWord = words[random.nextInt(words.length)];

        scrambledWord = scrambleWord(currentWord);

        wordLabel.setText(scrambledWord);

        answerField.setText("");
    }

    String scrambleWord(String word) {

        char[] letters = word.toCharArray();

        for (int i = 0; i < letters.length; i++) {

            int j = random.nextInt(letters.length);

            char temp = letters[i];

            letters[i] = letters[j];
            letters[j] = temp;
        }

        return new String(letters);
    }

    void checkAnswer() {

        String answer = answerField.getText().trim().toUpperCase();

        if (answer.equals(currentWord)) {

            score += 10;

            scoreLabel.setText("Score: " + score);

            if (score > highScore) {
                highScore = score;
            }

            JOptionPane.showMessageDialog(
                    this,
                    "Correct Answer!\n+10 Points"
            );

            nextWord();

        } else {

            JOptionPane.showMessageDialog(
                    this,
                    "Wrong Answer!\nTry Again."
            );
        }
    }

    void endGame() {

        timer.stop();

        answerField.setEnabled(false);
        submitButton.setEnabled(false);
        nextButton.setEnabled(false);

        if (score > highScore) {
            highScore = score;
        }

        JOptionPane.showMessageDialog(
                this,
                "Time's Up!\n\n" +
                        "Your Score: " + score +
                        "\nHigh Score: " + highScore,
                "Game Over",
                JOptionPane.INFORMATION_MESSAGE
        );
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            week7 game = new week7();

            game.setVisible(true);
        });
    }
}
