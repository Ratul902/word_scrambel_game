import java.util.Scanner;

public class Week3 {

    public static void main(String[] args) {

        String originalWord = "APPLE";

        Scanner input = new Scanner(System.in);

        System.out.println("Scrambled Word: PPAEL");

        System.out.print("Enter your guess: ");
        String guess = input.nextLine();

        if (guess.equalsIgnoreCase(originalWord)) {
            System.out.println("Correct! You guessed the word.");
        } else {
            System.out.println("Incorrect! Try Again.");
        }

        input.close();
    }
}