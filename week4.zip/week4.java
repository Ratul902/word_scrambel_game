import java.util.Scanner;

public class week4 {

    public static void main(String[] args) {

        String originalWord = "BANANA";
        int score = 0;

        Scanner input = new Scanner(System.in);

        System.out.println("================================");
        System.out.println("       WORD SCRAMBLE GAME");
        System.out.println("================================");

        System.out.println("Scrambled Word: NABANA");

        System.out.print("Enter your guess: ");
        String guess = input.nextLine();

        if (guess.equalsIgnoreCase(originalWord)) {

            score += 5;

            System.out.println("Correct! You guessed the word.");
            System.out.println("You earned 10 points.");

        } else {
            System.out.println("Incorrect! Try Again.");
            System.out.println("You earned 0 points.");
        }
        System.out.println("--------------------------------");
        System.out.println("Your Score: " + score);
        System.out.println("--------------------------------");


        input.close();
    }
}

