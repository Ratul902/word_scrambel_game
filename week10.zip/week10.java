import javax.swing.*;
import java.awt.*;
import java.util.Random;

public class week10 extends JFrame {

    String[] easyWords = {
            "APPLE", "BANANA", "ORANGE", "TABLE", "CHAIR",
            "WATER", "SCHOOL", "HOUSE", "GREEN", "TIGER"
    };

    String[] mediumWords = {
            "COMPUTER", "KEYBOARD", "INTERNET", "PROGRAMMING",
            "ELEPHANT", "UNIVERSITY", "LANGUAGE", "DEVELOPER",
            "SOFTWARE", "DATABASE"
    };

    String[] hardWords = {
            "ALGORITHM", "INHERITANCE", "POLYMORPHISM",
            "ENCAPSULATION", "ABSTRACTION", "CONSTRUCTOR",
            "RECURSION", "ARCHITECTURE", "PROGRAMMER",
            "DEVELOPMENT"
    };

    String currentWord;
    String scrambledWord;

    int score = 0;
    int highScore = 0;
    int round = 1;
    int totalRounds = 10;
    int timeLeft = 30;

    String difficulty = "Easy";

    Random random = new Random();
    Timer timer;

    JLabel roundLabel;
    JLabel scoreLabel;
    JLabel highScoreLabel;
    JLabel timerLabel;
    JLabel levelLabel;

    JLabel wordLabel;
    JLabel messageLabel;
    JLabel hintLabel;

    JTextField answerField;

    JButton submitButton;
    JButton hintButton;
    JButton nextButton;
    JButton restartButton;
    JButton exitButton;

    JComboBox<String> difficultyBox;

    Color backgroundColor = new Color(18, 22, 50);
    Color cardColor = new Color(35, 43, 82);

    Color purple = new Color(124, 77, 255);
    Color blue = new Color(33, 150, 243);
    Color green = new Color(46, 204, 113);
    Color red = new Color(231, 76, 60);
    Color yellow = new Color(255, 193, 7);

    Color white = Color.WHITE;

    public week10() {

        setTitle("Word Scramble Game - Final Version");

        setSize(1000, 720);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setLocationRelativeTo(null);

        setResizable(false);

        showWelcomeScreen();
    }

    void showWelcomeScreen() {

        if (timer != null) {
            timer.stop();
        }

        getContentPane().removeAll();

        JPanel main = new JPanel(new BorderLayout(20, 20));

        main.setBackground(backgroundColor);

        main.setBorder(
                BorderFactory.createEmptyBorder(
                        40, 100, 40, 100
                )
        );

        JLabel title = new JLabel(
                "WORD SCRAMBLE GAME",
                SwingConstants.CENTER
        );

        title.setFont(
                new Font("Arial", Font.BOLD, 44)
        );

        title.setForeground(yellow);

        JLabel subtitle = new JLabel(
                "<html><center>" +
                        "CHALLENGE YOUR BRAIN!<br><br>" +
                        "UNSCRAMBLE THE WORD AND EARN POINTS" +
                        "</center></html>",
                SwingConstants.CENTER
        );

        subtitle.setFont(
                new Font("Arial", Font.BOLD, 18)
        );

        subtitle.setForeground(
                new Color(220, 225, 255)
        );

        JPanel center = new JPanel();

        center.setLayout(
                new GridLayout(4, 1, 15, 15)
        );

        center.setBackground(backgroundColor);

        JLabel selectLabel = new JLabel(
                "SELECT DIFFICULTY",
                SwingConstants.CENTER
        );

        selectLabel.setFont(
                new Font("Arial", Font.BOLD, 18)
        );

        selectLabel.setForeground(white);

        difficultyBox = new JComboBox<>(
                new String[]{
                        "Easy",
                        "Medium",
                        "Hard"
                }
        );

        difficultyBox.setFont(
                new Font("Arial", Font.BOLD, 18)
        );

        difficultyBox.setBackground(Color.WHITE);

        JButton startButton =
                createButton(
                        "START GAME",
                        green
                );

        JButton instructionButton =
                createButton(
                        "HOW TO PLAY",
                        blue
                );

        center.add(selectLabel);
        center.add(difficultyBox);
        center.add(startButton);
        center.add(instructionButton);

        startButton.addActionListener(e -> {

            difficulty =
                    difficultyBox
                            .getSelectedItem()
                            .toString();

            startGame();
        });

        instructionButton.addActionListener(
                e -> showInstructions()
        );

        main.add(
                title,
                BorderLayout.NORTH
        );

        main.add(
                subtitle,
                BorderLayout.CENTER
        );

        main.add(
                center,
                BorderLayout.SOUTH
        );

        add(main);

        revalidate();
        repaint();
    }

    JButton createButton(
            String text,
            Color color
    ) {

        JButton button =
                new JButton(text);

        button.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        16
                )
        );

        button.setForeground(Color.WHITE);

        button.setBackground(color);

        button.setFocusPainted(false);

        button.setBorder(
                BorderFactory.createEmptyBorder(
                        12, 20, 12, 20
                )
        );

        return button;
    }

    void showInstructions() {

        JOptionPane.showMessageDialog(
                this,

                "1. Select a difficulty level.\n\n" +
                        "2. A scrambled word will appear.\n\n" +
                        "3. Type the correct word.\n\n" +
                        "4. Click SUBMIT ANSWER.\n\n" +
                        "5. Use HINT if you need help.\n\n" +
                        "6. Each round has 30 seconds.\n\n" +
                        "7. Correct answers give points.\n\n" +
                        "8. Complete 10 rounds.\n\n" +
                        "9. Try to achieve the highest score!",

                "HOW TO PLAY",

                JOptionPane.INFORMATION_MESSAGE
        );
    }

    void startGame() {

        score = 0;

        round = 1;

        timeLeft = 30;

        createGameScreen();

        loadNewWord();

        startTimer();
    }

    void createGameScreen() {

        getContentPane().removeAll();

        JPanel main =
                new JPanel(
                        new BorderLayout(
                                15,
                                15
                        )
                );

        main.setBackground(
                backgroundColor
        );

        main.setBorder(
                BorderFactory.createEmptyBorder(
                        20,
                        35,
                        20,
                        35
                )
        );

        JLabel title =
                new JLabel(
                        "WORD SCRAMBLE GAME",
                        SwingConstants.CENTER
                );

        title.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        36
                )
        );

        title.setForeground(yellow);

        main.add(
                title,
                BorderLayout.NORTH
        );

        JPanel stats =
                new JPanel(
                        new GridLayout(
                                1,
                                5,
                                12,
                                0
                        )
                );

        stats.setBackground(
                backgroundColor
        );

        stats.setPreferredSize(
                new Dimension(
                        0,
                        50
                )
        );

        roundLabel =
                createStatLabel(
                        "ROUND: 1/10",
                        purple
                );

        scoreLabel =
                createStatLabel(
                        "SCORE: 0",
                        blue
                );

        highScoreLabel =
                createStatLabel(
                        "HIGH SCORE: " + highScore,
                        yellow
                );

        timerLabel =
                createStatLabel(
                        "TIME: 30",
                        red
                );

        levelLabel =
                createStatLabel(
                        "LEVEL: " +
                                difficulty.toUpperCase(),
                        green
                );

        stats.add(roundLabel);
        stats.add(scoreLabel);
        stats.add(highScoreLabel);
        stats.add(timerLabel);
        stats.add(levelLabel);

        JPanel center =
                new JPanel();

        center.setLayout(
                new BoxLayout(
                        center,
                        BoxLayout.Y_AXIS
                )
        );

        center.setBackground(
                backgroundColor
        );

        JPanel wordCard =
                new JPanel(
                        new BorderLayout()
                );

        wordCard.setBackground(
                cardColor
        );

        wordCard.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                purple,
                                4
                        ),
                        BorderFactory.createEmptyBorder(
                                10,
                                20,
                                10,
                                20
                        )
                )
        );

        wordCard.setPreferredSize(
                new Dimension(
                        0,
                        155
                )
        );

        wordCard.setMinimumSize(
                new Dimension(
                        0,
                        155
                )
        );

        wordCard.setMaximumSize(
                new Dimension(
                        Integer.MAX_VALUE,
                        155
                )
        );

        JLabel instruction =
                new JLabel(
                        "UNSCRAMBLE THIS WORD",
                        SwingConstants.CENTER
                );

        instruction.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        19
                )
        );

        instruction.setForeground(
                new Color(
                        190,
                        200,
                        255
                )
        );

        wordLabel =
                new JLabel(
                        "LOADING...",
                        SwingConstants.CENTER
                );

        wordLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        48
                )
        );

        wordLabel.setForeground(yellow);

        wordCard.add(
                instruction,
                BorderLayout.NORTH
        );

        wordCard.add(
                wordLabel,
                BorderLayout.CENTER
        );

        center.add(wordCard);

        center.add(
                Box.createVerticalStrut(15)
        );

        JPanel answerPanel =
                new JPanel(
                        new BorderLayout(
                                12,
                                0
                        )
                );

        answerPanel.setBackground(
                backgroundColor
        );

        answerPanel.setPreferredSize(
                new Dimension(
                        0,
                        70
                )
        );

        answerPanel.setMinimumSize(
                new Dimension(
                        0,
                        70
                )
        );

        answerPanel.setMaximumSize(
                new Dimension(
                        Integer.MAX_VALUE,
                        70
                )
        );

        answerField =
                new JTextField();

        answerField.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        24
                )
        );

        answerField.setHorizontalAlignment(
                JTextField.CENTER
        );

        answerField.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                blue,
                                3
                        ),
                        BorderFactory.createEmptyBorder(
                                5,
                                10,
                                5,
                                10
                        )
                )
        );

        submitButton =
                createButton(
                        "SUBMIT ANSWER",
                        blue
                );

        answerPanel.add(
                answerField,
                BorderLayout.CENTER
        );

        answerPanel.add(
                submitButton,
                BorderLayout.EAST
        );

        center.add(answerPanel);

        center.add(
                Box.createVerticalStrut(10)
        );

        hintLabel =
                new JLabel(
                        " ",
                        SwingConstants.CENTER
                );

        hintLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        17
                )
        );

        hintLabel.setForeground(yellow);

        hintLabel.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        hintLabel.setPreferredSize(
                new Dimension(
                        0,
                        30
                )
        );

        hintLabel.setMinimumSize(
                new Dimension(
                        0,
                        30
                )
        );

        hintLabel.setMaximumSize(
                new Dimension(
                        Integer.MAX_VALUE,
                        30
                )
        );

        center.add(hintLabel);

        center.add(
                Box.createVerticalStrut(5)
        );

        messageLabel =
                new JLabel(
                        "UNSCRAMBLE THE WORD!",
                        SwingConstants.CENTER
                );

        messageLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        18
                )
        );

        messageLabel.setForeground(white);

        messageLabel.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        messageLabel.setPreferredSize(
                new Dimension(
                        0,
                        35
                )
        );

        messageLabel.setMinimumSize(
                new Dimension(
                        0,
                        35
                )
        );

        messageLabel.setMaximumSize(
                new Dimension(
                        Integer.MAX_VALUE,
                        35
                )
        );

        center.add(messageLabel);

        JPanel bottom =
                new JPanel(
                        new GridLayout(
                                1,
                                4,
                                12,
                                0
                        )
                );

        bottom.setBackground(
                backgroundColor
        );

        bottom.setPreferredSize(
                new Dimension(
                        0,
                        55
                )
        );

        hintButton =
                createButton(
                        "HINT",
                        yellow
                );

        nextButton =
                createButton(
                        "NEXT WORD",
                        green
                );

        restartButton =
                createButton(
                        "RESTART",
                        purple
                );

        exitButton =
                createButton(
                        "EXIT",
                        red
                );

        bottom.add(hintButton);
        bottom.add(nextButton);
        bottom.add(restartButton);
        bottom.add(exitButton);

        main.add(
                stats,
                BorderLayout.CENTER
        );

        JPanel gameContainer =
                new JPanel(
                        new BorderLayout(
                                0,
                                12
                        )
                );

        gameContainer.setBackground(
                backgroundColor
        );

        gameContainer.add(
                stats,
                BorderLayout.NORTH
        );

        gameContainer.add(
                center,
                BorderLayout.CENTER
        );

        gameContainer.add(
                bottom,
                BorderLayout.SOUTH
        );

        main.removeAll();

        main.add(
                title,
                BorderLayout.NORTH
        );

        main.add(
                gameContainer,
                BorderLayout.CENTER
        );

        add(main);

        submitButton.addActionListener(
                e -> checkAnswer()
        );

        answerField.addActionListener(
                e -> checkAnswer()
        );

        hintButton.addActionListener(
                e -> giveHint()
        );

        nextButton.addActionListener(
                e -> nextRound()
        );

        restartButton.addActionListener(
                e -> startGame()
        );

        exitButton.addActionListener(e -> {

            if (timer != null) {
                timer.stop();
            }

            showWelcomeScreen();
        });

        revalidate();

        repaint();
    }

    JLabel createStatLabel(
            String text,
            Color color
    ) {

        JLabel label =
                new JLabel(
                        text,
                        SwingConstants.CENTER
                );

        label.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        14
                )
        );

        label.setForeground(
                Color.WHITE
        );

        label.setOpaque(true);

        label.setBackground(color);

        label.setBorder(
                BorderFactory.createEmptyBorder(
                        10,
                        5,
                        10,
                        5
                )
        );

        return label;
    }

    void loadNewWord() {

        String[] words;

        if (
                difficulty.equals("Easy")
        ) {

            words = easyWords;

        } else if (
                difficulty.equals("Medium")
        ) {

            words = mediumWords;

        } else {

            words = hardWords;
        }

        currentWord =
                words[
                        random.nextInt(
                                words.length
                        )
                        ];

        scrambledWord =
                scramble(currentWord);

        while (
                scrambledWord.equals(
                        currentWord
                )
        ) {

            scrambledWord =
                    scramble(currentWord);
        }

        wordLabel.setText(
                scrambledWord.toUpperCase()
        );

        roundLabel.setText(
                "ROUND: " +
                        round +
                        "/" +
                        totalRounds
        );

        scoreLabel.setText(
                "SCORE: " +
                        score
        );

        highScoreLabel.setText(
                "HIGH SCORE: " +
                        highScore
        );

        levelLabel.setText(
                "LEVEL: " +
                        difficulty.toUpperCase()
        );

        answerField.setText("");

        hintLabel.setText(" ");

        messageLabel.setText(
                "UNSCRAMBLE THE WORD!"
        );

        messageLabel.setForeground(
                white
        );

        submitButton.setEnabled(true);

        timeLeft = 30;

        timerLabel.setText(
                "TIME: " +
                        timeLeft
        );

        timerLabel.setBackground(red);

        answerField.requestFocus();
    }

    String scramble(String word) {

        char[] letters =
                word.toCharArray();

        for (
                int i = letters.length - 1;
                i > 0;
                i--
        ) {

            int j =
                    random.nextInt(
                            i + 1
                    );

            char temp =
                    letters[i];

            letters[i] =
                    letters[j];

            letters[j] =
                    temp;
        }

        return new String(letters);
    }

    void checkAnswer() {

        String answer =
                answerField
                        .getText()
                        .trim()
                        .toUpperCase();

        if (answer.isEmpty()) {

            messageLabel.setText(
                    "PLEASE ENTER AN ANSWER!"
            );

            messageLabel.setForeground(
                    yellow
            );

            return;
        }

        if (
                answer.equals(
                        currentWord
                )
        ) {

            int points;

            if (
                    difficulty.equals(
                            "Easy"
                    )
            ) {

                points = 10;

            } else if (
                    difficulty.equals(
                            "Medium"
                    )
            ) {

                points = 20;

            } else {

                points = 30;
            }

            score += points;

            if (score > highScore) {

                highScore = score;
            }

            scoreLabel.setText(
                    "SCORE: " +
                            score
            );

            highScoreLabel.setText(
                    "HIGH SCORE: " +
                            highScore
            );

            messageLabel.setText(
                    "CORRECT! +" +
                            points +
                            " POINTS"
            );

            messageLabel.setForeground(
                    green
            );

            submitButton.setEnabled(false);

        } else {

            messageLabel.setText(
                    "WRONG ANSWER! TRY AGAIN"
            );

            messageLabel.setForeground(
                    red
            );

            answerField.selectAll();
        }
    }

    void giveHint() {

        if (currentWord == null) {
            return;
        }

        String hint =
                "FIRST LETTER: " +
                        currentWord.charAt(0);

        hint +=
                "   |   LENGTH: " +
                        currentWord.length();

        hintLabel.setText(hint);

        if (score >= 5) {

            score -= 5;

            scoreLabel.setText(
                    "SCORE: " +
                            score
            );
        }

        messageLabel.setText(
                "HINT USED! 5 POINTS DEDUCTED."
        );

        messageLabel.setForeground(
                yellow
        );
    }

    void nextRound() {

        if (
                round >= totalRounds
        ) {

            finishGame();

            return;
        }

        round++;

        loadNewWord();
    }

    void startTimer() {

        if (timer != null) {

            timer.stop();
        }

        timer =
                new Timer(
                        1000,
                        e -> {

                            timeLeft--;

                            timerLabel.setText(
                                    "TIME: " +
                                            timeLeft
                            );

                            if (
                                    timeLeft <= 10
                            ) {

                                timerLabel.setBackground(
                                        red
                                );

                            } else {

                                timerLabel.setBackground(
                                        new Color(
                                                52,
                                                73,
                                                94
                                        )
                                );
                            }

                            if (
                                    timeLeft <= 0
                            ) {

                                timer.stop();

                                messageLabel.setText(
                                        "TIME'S UP! WORD: " +
                                                currentWord
                                );

                                messageLabel.setForeground(
                                        red
                                );

                                submitButton.setEnabled(
                                        false
                                );
                            }
                        }
                );

        timer.start();
    }

    void finishGame() {

        if (timer != null) {

            timer.stop();
        }

        String performance;

        if (score >= 200) {

            performance =
                    "EXCELLENT PERFORMANCE!";

        } else if (score >= 100) {

            performance =
                    "GREAT JOB!";

        } else {

            performance =
                    "GOOD TRY!";
        }

        JOptionPane.showMessageDialog(
                this,

                "GAME COMPLETED!\n\n" +
                        "DIFFICULTY: " +
                        difficulty.toUpperCase() +
                        "\n" +
                        "FINAL SCORE: " +
                        score +
                        "\n" +
                        "HIGH SCORE: " +
                        highScore +
                        "\n\n" +
                        performance,

                "FINAL RESULT",

                JOptionPane.INFORMATION_MESSAGE
        );

        showWelcomeScreen();
    }

    public static void main(
            String[] args
    ) {

        SwingUtilities.invokeLater(() -> {

            week10 game =
                    new week10();

            game.setVisible(true);
        });
    }
}