
public class Week1 {

    public static void main(String[] args) {


        System.out.println("=================================");
        System.out.println("     WORD SCRAMBLE GAME");
        System.out.println("=================================");
        System.out.println("Welcome to the Word Scramble Game!");
        System.out.println();


        String[] words = {
                "APPLE",
                "BANANA",
                "JAVA",
                "PROGRAM",
                "KEYBOARD",
                "MOUSE",
                "MONITOR",
                "SCREEN",
                "COMPUTER",
                "LANGUAGE"
        };

       
        System.out.println("Word Bank Created Successfully!");
        System.out.println("Total Number of Words: " + words.length);
        System.out.println();


        System.out.println("Words in the Word Bank:");
        for (int i = 0; i < words.length; i++) {
            System.out.println((i + 1) + ". " + words[i]);
        }

        System.out.println();
        System.out.println("Week 1 Setup Completed Successfully!");
    }
}




























